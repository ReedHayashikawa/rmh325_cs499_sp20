# Symbolic execution

TODO:
- something general about SE
- something about angr and manticore
- how DeepState integrates SE (simplified stuff from the paper)
